<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class more extends CI_Controller 
{
	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	if($_SESSION['user_logged'] == FALSE)
		{
			$this->session->set_flashdata("error", "Please Login");
			redirect('auth/login');
		}
}
	public function index()
	{
		$name = $this->session->userdata('username'); 
		$query = $this->db->query("insert into read_e (username, money) values ('$name', '5')");
	}
}