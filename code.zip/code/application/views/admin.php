<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin - Login</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
	<style type="text/css">
	.login-form {
		width: 340px;
    	margin: 50px auto;
	}
    .login-form form {
    	margin-bottom: 15px;
        background: #f7f7f7;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }
    .login-form h2 {
        margin: 0 0 15px;
    }
    .form-control, .btn {
        min-height: 38px;
        border-radius: 2px;
    }
    .btn {        
        font-size: 15px;
        font-weight: bold;
    }
</style>
</head>
<body>
		<div class="container"></div>
		<form action="" method="post">
<div class="login-form">
        <?php echo validation_errors('<div class="alert alert-danger">','</div>'); ?>
    <?php if(isset($_SESSION['success'])){ 
        ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
        <?php  
    }
        ?> 
     <?php if(isset($_SESSION['error'])){ 
        ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; ?></div>
        <?php  
    }
        ?> 
    <form action="" method="post">
        <h1 class="text-primary">Login - Admin</h1>   
        <div class="form-group">
            <input type="text" class="form-control" placeholder="Username" name="username">
        </div>
        <div class="form-group">
            <input type="password" class="form-control" placeholder="Password" name="password">
        </div>
        <div class="form-group">
            <button type="submit" name="login" class="btn btn-primary btn-block">Log in</button>
        </div>
</div>

<script type='text/javascript' src="<?php echo base_url(); ?>assets/js/bootstrap.js"></script>
</body>
</html>