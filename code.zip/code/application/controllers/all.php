<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class all extends CI_Controller 
{
	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();

	/*load database libray manually*/
	$this->load->database();
	
	/*load Model*/
	$this->load->model('home_m');
	}

	public function read($id)
	{
		if(isset($_POST['sub']))
		{
			
			$username = $_POST['username'];
			$comments = $_POST['comment'];
			$t_at = date('Y-m-d');
			$post_id = $_POST['post_id'];
			

			$query = $this->db->query("insert into comments (username, comment, post_id, t_at) values ('$username', '$comments', '$post_id', '$t_at')");
			redirect(current_url(), 'refresh');
		}

		$result['data']=$this->home_m->read_new($id);
		$this->load->view('read_news', $result);
	}
public function bbm($id)
{

	
}


	/*public function comment($id)
	{
		if(isset($_POST['sub']))
		{

			$username = $_POST['username'];
			$post_id = $_POST['post_id'];
			$comment = $_POST['comment'];

			$query = $this->db->query("insert into comments (username, comment, post_id) values ('$username', '$comment', '$post_id'");
			$this->load->view('read_news');
		}
	} */
}