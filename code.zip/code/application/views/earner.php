<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class more extends CI_Controller 
{
	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
}
	public function index()
	{
		
	}
}