<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin - Dashboard</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
<!-- Custom styles for this template -->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/blog-home.css">
	<style type="text/css">
    </style>
</head>
<body>
        <?php echo validation_errors('<div class="alert alert-danger">','</div>'); ?>
    <?php if(isset($_SESSION['success'])){ 
        ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
        <?php  
    }
        ?> 
        <?php if(isset($_SESSION['error'])){ 
        ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; ?></div>
        <?php  
    }
        ?> 

     <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Hello, <?php echo $_SESSION['username']; ?></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="#">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>index.php/admin/logout">Logout</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>index.php">Main Page</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
<!-- Page Content -->
  <div class="container">

    <div class="row">

      <!-- Blog Entries Column -->
      <div class="col-md-8">

        <h1 class="my-4 text-primary"> Blog
          <small>Update</small>
        </h1>
        <?php echo $this->session->flashdata('success_msg'); ?>
<?php echo $this->session->flashdata('error_msg'); ?>
<form role="form" action="add" method="post" enctype="multipart/form-data">
    <div class="panel">
        <div class="panel-body">
            <div class="form-group">
                <label>Image</label>
                <input class="form-control" type="file" name="image" />
            </div>
            <div class="form-group">
                <label>Title</label>
                <input class="form-control" type="text" name="title" />
            </div>
            <div class="form-group">
                <label>Content</label>
                <textarea class="form-control" type="text" name="content" ></textarea>
            </div>
              <div class="form-group">
                <label>Category</label>
                
<select name="cat" id="cat">
  <option value="sport">Sport</option>
  <option value="politics">Politics</option>
  <option value="latest">Latest news</option>
  <option value="games">Game</option>
</select>
            </div>
             <div class="form-group">
                <label></label>
                <input class="form-control" type="hidden" name="by_who" value="<?php echo $_SESSION['username']; ?>" />
            </div>
             <div class="form-group">
                <input type="submit" class="btn btn-warning" name="post" value="Add">
            </div>
        </div>
    </div>
</form>

<?php
print "Your IP address is ".$_SERVER['REMOTE_ADDR'];
?>



<script type='text/javascript' src="<?php echo base_url(); ?>assets/js/bootstrap.js"></script>
</body>
</html>