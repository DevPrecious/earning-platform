<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller 
{
	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();

	
	/*load database libray manually*/
	$this->load->database();
	
	/*load Model*/
	$this->load->model('home_m');
	}
   /*Display*/
	public function index()
	{
	$result['data']=$this->home_m->display_records();
	$this->load->view('home',$result);
	}

	
}
?>