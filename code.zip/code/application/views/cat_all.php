<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Post</title>

  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.css">

  <!-- Custom styles for this template -->
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/blog-home.css">



</head>

<body>

 <?php  $name = $this->session->userdata('username'); 
if($name == FALSE)
{
 ?>
 <?php echo '
  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Sunbiz</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href='.base_url().'>Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href='.base_url().'index.php/auth/login>Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php/auth/register">Register</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>';
  ?>
<?php }
else {
?>
<?php echo ' <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Sunbiz</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href='.base_url().'>Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href='.base_url().'index.php/user/profile>Dashboard</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>';
  ?>
<?php }?>

  <!-- Page Content -->
  <div class="container">

    <div class="row">

      <!-- Post Content Column -->
      <div class="col-lg-8">

    <?php 
      foreach ($data as $datas)
      {
        ?>
        <h1 class="my-4"> Blog posts</h1>
        <!-- Blog Post -->
        <div class="card mb-4">
          <img class="card-img-top" src="<?php echo base_url() . 'uploads/images/'.$datas->image; ?>" alt="post"> 
          <div class="card-body">
            <h2 class="card-title"><?php echo $datas->title; ?></h2>
            <p class="card-text text-truncate"><?php echo $datas->content; ?></p>
            <a href="<?php echo base_url().'index.php/all/read/'.$datas->id; ?>" class="btn btn-primary" onclick="earn()">Read More &rarr;</a>
          </div>
          <div class="card-footer text-muted">
            Posted on <?php echo $datas->created_at; ?> by
            <a href="#"><?php echo $datas->by_who; ?></a> |
            <a href="index.php/cat/all/<?php echo $datas->category; ?>"><?php echo $datas->category; ?></a>
          </div>
        </div>
      <?php }?>
