<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Welcome | <?php echo $_SESSION['username']; ?></title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
	<style type="text/css">
    </style>
</head>
<body>
    <div class="container">
        <?php echo validation_errors('<div class="alert alert-danger">','</div>'); ?>
    <?php if(isset($_SESSION['success'])){ 
        ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
        <?php  
    }
        ?> 
        <?php if(isset($_SESSION['error'])){ 
        ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; ?></div>
        <?php  
    }
        ?> 
   Hello, <?php echo $_SESSION['username']; ?>
</div>
<?php  $name = $this->session->userdata('username'); 
if($name == FALSE)
{
 ?>
 <?php echo '
  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Sunbiz</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="#">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php/auth/login">Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php/auth/register">Register</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>';
  ?>
<?php }
else {
?>
<?php echo ' <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Sunbiz</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">'.'
            <a class="nav-link" href='.base_url().'>Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href='.base_url().'index.php/auth/logout>Logout</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="user/profile">Dashboard</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>';
  ?>
<?php }?>
<!-- Page Content -->
<div class="container">
    <div class="row">
     
      <!-- Blog Entries Column -->
      <div class="col">
 <?php 
      foreach ($data1 as $datas)
      {
        ?>
        <h1 class="my-4"> Profile</h1>
        <!-- Blog Post -->
        <div class="card">
            <img class="" width="100" height="100" src="<?php echo base_url() . 'uploads/images/'.$datas->image; ?>" alt="post"> 
            <h4 class="card-title">Registerd Email: <?php echo $datas->email; ?></h2>
            <p class="card-text text-truncate">Phone number: <?php echo $datas->phone; ?></p>
          </div>
          <div class="card-footer text-muted">
           Country: <?php echo $datas->country; ?> 
            <a href="#"><?php echo $datas->ref; ?></a>
          </div>
        </div>
    </h4>
</div>
    
      <div class="row">
      <div class="col">
        <h1 class="my-4"> Update profile</h1>
         <?php echo $this->session->flashdata('success_msg'); ?>
<?php echo $this->session->flashdata('error_msg'); ?>
<form role="form" action="add" method="post" enctype="multipart/form-data">
    <div class="panel">
        <div class="panel-body">
            <div class="form-group">
                <label>Profile pics</label>
                <input class="form-control" type="file" name="image" value="<?php echo $datas->image; ?>" required />
            </div>
            <div class="form-group">
                <label>Username</label>
                <input class="form-control" type="text" name="username" value="<?php echo $datas->username; ?>" required />
            </div>
            <div class="form-group">
                <label>Email</label>
                <input class="form-control" type="email" name="email" value="<?php echo $datas->email; ?>" required />
            </div>
             <div class="form-group">
                <input type="submit" class="btn btn-warning" name="update" value="Update">
            </div>
        </div>
    </div>

</form>
<?php }?>

        <h1 class="my-4"> Earnings Section</h1>
        <p>Refferal link : <?php echo base_url(); ?>index.php/auth/join/<?php echo $datas->username; ?></p>
        <p><button class="btn outline-primary"><a href="earn">Check Earnings</a></button>

  <!-- Bootstrap core JavaScript -->
  <script src="<?php echo base_url(); ?>assets/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>