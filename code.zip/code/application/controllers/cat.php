<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class cat extends CI_Controller 
{
	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();

	
	/*load database libray manually*/
	$this->load->database();
	
	/*load Model*/
	$this->load->model('home_m');
	}
   /*Display*/

public function all($string)
	{
		$result['data']=$this->home_m->load_cat($string);
		$this->load->view('cat_all', $result);
	}
	
}
?>	