<?php

class user extends CI_Controller
{
	

	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	if($_SESSION['user_logged'] == FALSE)
		{
			$this->session->set_flashdata("error", "Please Login");
			redirect('auth/login');
		}
	/*load database libray manually*/
	$this->load->database();
	
	/*load Model*/
	$this->load->model('profile_m');
	$this->load->model('earn_m');	
	
	}
	public function profile()
	{
			if($_SESSION['user_logged'] == FALSE)
		{
			$this->session->set_flashdata("error", "Please Login");
			redirect('auth/login');
		}
		$username = $_SESSION['username'];
		$result['data1']=$this->profile_m->display_records($username);

		$all['data'] = $this->earn_m->earning($username);

		$this->load->view('profile',$result);
	}

	public function earn()
	{
			if($_SESSION['user_logged'] == FALSE)
		{
			$this->session->set_flashdata("error", "Please Login");
			redirect('auth/login');
		}
		$username = $_SESSION['username'];

		$all['data'] = $this->earn_m->earning($username);
		$this->load->view('earn', $all);

	}

	function add(){
		$username = $_SESSION['username'];
        if($this->input->post('update')){
            
            //Check whether user upload picture
            if(!empty($_FILES['image']['name'])){
                $config['upload_path'] = 'uploads/images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['image']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = '';
                }
            }else{
                $picture = '';
            }
            
            //Prepare array of user data
            $use = $this->input->post('username');
            $email = $this->input->post('email');
            $image =  $picture;
            
            //Pass user data to model
           $result['data'] =  $this->db->query("update users set username='$use', email='$email', image='$image' where username='$username'");
            
            //Storing insertion status message.
            //if($insertUserData){
                $this->session->set_flashdata('success_msg', 'User data have been updated successfully.');
                redirect('user/profile', 'refresh');
            /*}else{
                $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
            }*/
        }
        //Form for adding user data
        $this->load->view('profile');
    }

             


}