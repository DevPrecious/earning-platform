<?php
class home_m extends CI_Model 
{
   /*View*/
	function display_records()
	{
	$query=$this->db->query("select * from posts order by id DESC");
	return $query->result();
	}
	
	function read_new($id)
	{
	$query=$this->db->query("select * from posts  where id = '$id'");
	return $query->result();
	}

	function load_comment($id)
	{
		$query=$this->db->query("select * from comments where post_id = '$id'");
	return $query->result();
	}
	
	function load_search()
	{
		$query=$this->db->query("select * from posts where title = '$se'");
	return $query->result();
	}

	function load_cat($string)
	{
	$query=$this->db->query("select * from posts  where category = '$string'");
	return $query->result();
	}
} 