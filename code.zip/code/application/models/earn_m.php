<?php
class earn_m extends CI_Model 
{
function earning($username)
	{
		$query = $this->db->select('*')->from('users')->where('ref', $username)->get();
		return $query->result();
	}

	function user_earning($username)
	{
		$query = $this->db->select('*')->from('users')->get();
		return $query->result();
	}
}
	