<?php
class profile_m extends CI_Model 
{
   /*View*/
	function display_records($username)
	{
	$query = $this->db->select('*')->from('users')->where('username',$username)->get();
	return $query->result();
	}
} 