<?php

class auth extends CI_Controller
{

	public function logout(){
		unset($_SESSION);
		session_destroy();
		$this->session->set_flashdata("error", "Successfully Logged out");
		redirect('auth/login', 'refresh');
	}

	public function login(){

		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
		if($this->form_validation->run() == TRUE){

			$username = $_POST['username'];
			$password = md5($_POST['password']);

			 $this->db->select('*');
			 $this->db->from('users');
			 $this->db->where(array('username'=>$username, 'password'=>$password));
			 $query = $this->db->get();

			 $user = $query->row();

			 if($user->email){
			 	$this->session->set_flashdata('success', 'You are logged in');

			 	$_SESSION['user_logged'] = TRUE;
			 	$_SESSION['username'] = $user->username;

			 	redirect('user/profile', 'refresh');
			 }else{
			 	$this->session->set_flashdata('error', 'Invalid username or password');
			 	redirect('auth/login', 'refresh');
			 }
		}

		$this->load->view('login');
	}
	public function register(){
		
		if(isset($_POST['join']))
		{
			$this->input->post('ref');
			$this->form_validation->set_rules('username', 'Username', 'required');
			$this->form_validation->set_rules('email', 'Email', 'required');
			$this->form_validation->set_rules('phone', 'Phone', 'required');
			$this->form_validation->set_rules('country', 'Country', 'required');
			$this->form_validation->set_rules('coupon', 'Coupon', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
			$this->form_validation->set_rules('c_password', 'Confirm Password', 'required|min_length[6]|matches[password]');

			if($this->form_validation->run() == TRUE){
				//echo 'form validated';
				$data = array(
					'ref'=>$_POST['ref'],
					'username'=>$_POST['username'],
					'email'=>$_POST['email'],
					'phone'=>$_POST['phone'],
					'country'=>$_POST['country'],
					'coupon'=>$_POST['coupon'],
					'password'=>md5($_POST['password']),
					'created_date'=>date('Y-m-d')
				);
				$where = array(
				  'coupon' => $_POST['coupon']
				);

				//$coupon = $this->input->post('coupon');

				 $this->db->select('coupon');
		$this->db->from('users');
		$this->db->where($where);
		$num_results = $this->db->count_all_results();
			 	if($num_results>0){
			 		echo "<div class='container'><div class='alert alert-danger'>Coupon has been used</div></div>";
			 	}
			 	else{	

			 		$where = array(
				  'coupon' => $_POST['coupon']
				);
			 		 $this->db->select('coupon');
		$this->db->from('coupons');
		$this->db->where($where);
		$num_results = $this->db->count_all_results();
		if($num_results>0){


				$this->db->insert('users', $data);

				$this->session->set_flashdata("success", "Your account has been created, you can now login");
				redirect('auth/register', 'refresh');
			}
			else{
				echo "<div class='container'><div class='alert alert-danger'>Coupon is inavlid</div></div>";
			}
		}
			}
		}

		$this->load->view('register');

	}

	public function join($username)
	{
		$data1 = array(
			'user' => $username
		);

		if(isset($_POST['join']))
		{
			$this->input->post('ref');
			$this->form_validation->set_rules('username', 'Username', 'required');
			$this->form_validation->set_rules('email', 'Email', 'required');
			$this->form_validation->set_rules('phone', 'Phone', 'required');
			$this->form_validation->set_rules('country', 'Country', 'required');
			$this->form_validation->set_rules('coupon', 'Coupon', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
			$this->form_validation->set_rules('c_password', 'Confirm Password', 'required|min_length[6]|matches[password]');

			if($this->form_validation->run() == TRUE){
				//echo 'form validated';
				$data = array(
					'ref'=> $_POST['ref'],
					'username'=>$_POST['username'],
					'email'=>$_POST['email'],
					'phone'=>$_POST['phone'],
					'country'=>$_POST['country'],
					'coupon'=>$_POST['coupon'],
					'password'=>md5($_POST['password']),
					'created_date'=>date('Y-m-d')
				);
				$where = array(
				  'coupon' => $_POST['coupon']
				);

				//$coupon = $this->input->post('coupon');

				 $this->db->select('coupon');
		$this->db->from('users');
		$this->db->where($where);
		$num_results = $this->db->count_all_results();
			 	if($num_results>0){
			 		echo "<div class='container'><div class='alert alert-danger'>Coupon has been used</div></div>";
			 	}
			 	else{	

			 		$where = array(
				  'coupon' => $_POST['coupon']
				);
			 		 $this->db->select('coupon');
		$this->db->from('coupons');
		$this->db->where($where);
		$num_results = $this->db->count_all_results();
		if($num_results>0){


				$this->db->insert('users', $data);

				$this->session->set_flashdata("success", "Your account has been created, you can now login");
				redirect('auth/register', 'refresh');
			}
			else{
				echo "<div class='container'><div class='alert alert-danger'>Coupon is inavlid</div></div>";
			}
		}
			}
		}

		$this->load->view('ref', $data1);
	}
}