<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Post</title>

  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.css">

  <!-- Custom styles for this template -->
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/blog-home.css">



</head>

<body>

 <?php  $name = $this->session->userdata('username'); 
if($name == FALSE)
{
 ?>
 <?php echo '
  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Sunbiz</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href='.base_url().'>Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href='.base_url().'index.php/auth/login>Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php/auth/register">Register</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>';
  ?>
<?php }
else {
?>
<?php echo ' <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Sunbiz</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href='.base_url().'>Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href='.base_url().'index.php/user/profile>Dashboard</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>';
  ?>
<?php }?>

  <!-- Page Content -->
  <div class="container">

    <div class="row">

      <!-- Post Content Column -->
      <div class="col-lg-8">
 <?php 
      foreach ($data as $datas)
      {
        ?>
        <!-- Title -->
        <h1 class="mt-4"><?php echo $datas->title; ?></h1>
<?php  } ?>
        <!-- Author -->
        <p class="lead">
          by
          <a href="#"><?php echo $datas->by_who; ?></a>
        </p>

        <hr>

        <!-- Date/Time -->
        <p>Posted on <?php echo $datas->created_at; ?></p>

        <hr>

        <!-- Preview Image -->
        <img class="card-img-top" src="<?php echo base_url() . 'uploads/images/'.$datas->image; ?>" alt="post"> 

        <hr>

        <!-- Post Content -->
        <p class="lead"><?php echo $datas->content; ?>
 
        <hr>
<?php  $name = $this->session->userdata('username'); 
if($name == FALSE)
{
 ?>
 <?php echo "<div class='alert alert-danger'>You must login to comment</div>"; ?>
      <?php 
     $query=$this->db->query("select * from comments where post_id = '$datas->id'");
    foreach ($query->result() as $row)
    {?>
      <div class="media mb-4">
          <img class="d-flex mr-3 rounded-circle" src="http://placehold.it/50x50" alt="">
          <div class="media-body">
            <h5 class="mt-0"><?php echo $row->username;?> </h5>
            <?php echo $row->comment;?>
          </div>
        </div>

   <?php }?> 
 <?php } else {?>
 <?php echo '
        <!-- Comments Form -->
        <div class="card my-4">
          <h5 class="card-header">Leave a Comment:</h5>
          <div class="card-body">';
            echo "
            <form action='' method='post'>
              <input type='hidden'  value='$name' name='username' >
              <input type='hidden'  value='$datas->id' name='post_id' >
              ".'
              <div class="form-group">
                <textarea name="comment" class="form-control" required rows="3"></textarea>
              </div>
              <button type="submit" name="sub" class="btn btn-primary">Submit</button>
            </form>
          </div>
        </div>';
        ?>
       
        <?php 
     $query=$this->db->query("select * from comments where post_id = '$datas->id'");
    foreach ($query->result() as $row)
    {?>
      <div class="media mb-4">
          <img class="d-flex mr-3 rounded-circle" src="http://placehold.it/50x50" alt="">
          <div class="media-body">
            <h5 class="mt-0"><?php echo $row->username;?> </h5>
            <?php echo $row->comment;?>
            <br>
            <?php echo $row->t_at; ?>
          </div>
        </div>

   <?php }?> 
   <?php }?>
 </p>
</div>

      <?php 
if(isset($_POST['go']))
{
  $se = $_POST['search'];
$query = $this->db->query("select * from posts where title = '$se'");
foreach ($query->result() as $row)
{?>   <?php
       echo "<a href=".base_url()."index.php/all/read/$row->id>". $row->title; ?></a>
      <?php }}?>
      <!-- Sidebar Widgets Column -->
      <div class="col-md-4">

        <!-- Search Widget -->
        <div class="card my-4">
          <h5 class="card-header">Search</h5>
          <div class="card-body">
            <div class="input-group">
              <form action="" method="post">
              <input type="text" name="search" class="form-control" placeholder="Search for...">
           <br>
           <button name="go" class="btn btn-outline-primary">Go</button>
              </form>
              </span>
            </div>
          </div>
        </div>

        

        <!-- Side Widget -->
        <div class="card my-4">
          <h5 class="card-header">Side Widget</h5>
          <div class="card-body">
            You can put anything you want inside of these side widgets. They are easy to use, and feature the new Bootstrap 4 card containers!
          </div>
        </div>

      </div>

    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; <?php echo date("Y");?></p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="<?php echo base_url(); ?>assets/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
