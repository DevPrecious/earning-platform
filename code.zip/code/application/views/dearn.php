<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Welcome | <?php echo $_SESSION['username']; ?></title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
	<style type="text/css">
    table, th, td {
  border: 1px solid black;
}
    </style>
</head>
<body>
    <div class="container">
        <?php echo validation_errors('<div class="alert alert-danger">','</div>'); ?>
    <?php if(isset($_SESSION['success'])){ 
        ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
        <?php  
    }
        ?> 
        <?php if(isset($_SESSION['error'])){ 
        ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; ?></div>
        <?php  
    }
        ?> 
   Hello, <?php echo $_SESSION['username']; ?>
</div>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Hello, <?php echo $_SESSION['username']; ?></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="#">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>index.php/auth/logout">Logout</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>index.php">Main Page</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
<!-- Page Content -->
<div class="container">
    <div class="row">
      <div class="col">
      <div class="card">
        <h1 class="my-4"> Activities</h1>
        <h4 class="card-title">refferals</h4>
       <?php 
      foreach ($data as $datas)
      {
        ?>
        <?php 
echo '
<table class="table-hover  table-dark table-striped">
<tr>
      <th>Name</th>
      <th>Reffered</th>
    </tr>
    <tr>
      <td>'.$datas->ref.'</td>
      <td>'.$datas->username.'</td>
    </tr>
    </table>';
    ?>
        <?php }?>
      </div>
     <!-- Bootstrap core JavaScript -->
  <script src="<?php echo base_url(); ?>assets/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.bundle.min.js"></script>
     