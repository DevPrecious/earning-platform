<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Welcome | <?php echo $_SESSION['username']; ?></title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
	<style type="text/css">
    </style>
</head>
<body>
    <div class="container">
        <?php echo validation_errors('<div class="alert alert-danger">','</div>'); ?>
    <?php if(isset($_SESSION['success'])){ 
        ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
        <?php  
    }
        ?> 
        <?php if(isset($_SESSION['error'])){ 
        ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; ?></div>
        <?php  
    }
        ?> 
   Hello, <?php echo $_SESSION['username']; ?>
</div>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Hello, <?php echo $_SESSION['username']; ?></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="#">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>index.php/auth/logout">Logout</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url(); ?>index.php">Main Page</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
<!-- Page Content -->
<div class="container">
    <div class="row">
      <div class="col">
      <div class="card">
        <h1 class="my-4"> My Activities</h1>
        <h4 class="card-title">Your refferals earnings</h4>
       <?php  
       $user = $_SESSION['username'];
     $query=$this->db->query("select * from users where username = '$user'");
    foreach ($query->result() as $row)
    {?>
      <?php echo $row->money;?>
   <?php }?>
      </div>

               <?php 
               $user = $_SESSION['username'];
     $query=$this->db->query("select sum(money) as mon from read_e where username = '$user'");
    foreach ($query->result() as $row)
    {?>
            <h5 class="mt-0">Site Earnings:   <?php echo $row->mon;?> </h5>

   <?php }?> 

     <!-- Bootstrap core JavaScript -->
  <script src="<?php echo base_url(); ?>assets/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.bundle.min.js"></script>
     