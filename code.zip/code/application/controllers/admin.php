<?php

class admin extends CI_Controller
{
	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();

	
	/*load database libray manually*/
	$this->load->database();
	
	/*load Model*/
	$this->load->model('earn_m');
	}
       
		public function logout(){
		unset($_SESSION);
		session_destroy();
		$this->session->set_flashdata("error", "Successfully Logged out");
		redirect('admin/index', 'refresh');
	}

	public function index(){

$this->form_validation->set_rules('username', 'Username', 'required');
$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
		if($this->form_validation->run() == TRUE){

			$username = $_POST['username'];
			$password = md5($_POST['password']);

			 $this->db->select('*');
			 $this->db->from('admin');
			 $this->db->where(array('username'=>$username, 'password'=>$password));
			 $query = $this->db->get();

			 $user = $query->row();

			 if($user->password){
			 	$this->session->set_flashdata('success', 'You are logged in');

			 	$_SESSION['admin_logged'] = TRUE;
			 	$_SESSION['username'] = $user->username;

			 	redirect('admin/dashboard', 'refresh');
			 }else{
			 	$this->session->set_flashdata('error', 'Invalid username or password');
			 	redirect('admin/index', 'refresh');
			 }
		}

		$this->load->view('admin');
	}
	public function dashboard()
	{
			if($_SESSION['admin_logged'] == FALSE)
		{
			$this->session->set_flashdata("error", "Please Login");
			redirect('admin/index');
		}
		$this->load->view('dashboard');
	}

	function add(){
        if($this->input->post('post')){
            
            //Check whether user upload picture
            if(!empty($_FILES['image']['name'])){
                $config['upload_path'] = 'uploads/images/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['image']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('image')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = '';
                }
            }else{
                $picture = '';
            }
            
            //Prepare array of user data
            $userData = array(
                'title' => $this->input->post('title'),
                'content' => $this->input->post('content'),
                'image' => $picture,
                'by_who'=> $this->input->post('by_who'),
                'created_at'=>date('Y-m-s'),
                'category'=> $this->input->post('cat')
            );
            
            //Pass user data to model
            $this->db->insert('posts', $userData);
            
            //Storing insertion status message.
            //if($insertUserData){
                $this->session->set_flashdata('success_msg', 'User data have been added successfully.');
                redirect('dashboard', 'refresh');
            /*}else{
                $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
            }*/
        }
        //Form for adding user data
        $this->load->view('dashboard');
    }

    	public function earn()
	{
		$username = $_SESSION['admin_logged'];

		$all['data'] = $this->earn_m->user_earning($username);
		$this->load->view('dearn', $all);

	}

		
}

?>
